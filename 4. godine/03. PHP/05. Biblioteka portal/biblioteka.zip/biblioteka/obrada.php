<?php
include "./server.php";

switch($_GET['opcija']){
    case 
}
function izdavanje_knjige(){

}



?>